﻿

namespace Amdaris.Logging.Abstractions;
public interface IAmdarisLogger
{
    void Log(string message);
}
