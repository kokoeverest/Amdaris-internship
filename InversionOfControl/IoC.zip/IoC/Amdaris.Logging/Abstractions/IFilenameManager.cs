﻿
namespace Amdaris.Logging.Abstractions;
public interface IFilenameManager
{
    string CreateFileName();
}
